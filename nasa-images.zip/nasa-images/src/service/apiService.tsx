const fetchNasaImages = async (search?: string) => {
  let url = search
    ? `https://images-api.nasa.gov/search?q=${search}`
    : `https://images-assets.nasa.gov/recent.json`;

  try {
    const response = await fetch(url, { method: "GET" });
    const data = await response.json();
    return data.collection.items;
  } catch (error) {
    return { failedTofetch: true };
  }
};
export default fetchNasaImages;
