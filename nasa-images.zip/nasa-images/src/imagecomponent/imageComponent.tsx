import { Grid } from "@mui/material";
import { memo } from "react";
const Imagecomponent = ({ data }: any) => {
  return (
    <Grid container justifyContent="center" style={{ paddingTop: "20px" }}>
      <Grid item xs={11}>
        <Grid container justifyContent="space-around" spacing={1}>
          {data &&
            data?.map((image: any, index: number) => (
              <Grid item xs={2} key={index} sm={2} md={3}>
                <figure>
                  <img
                    src={image.links?.[0]?.href || ""}
                    alt={`Image ${image.data?.[0]?.title || ""}`}
                    style={{
                      border: "2px solid rgba(0, 0, 0, 0)",
                      display: "block",
                      width: "100%",
                    }}
                  />
                </figure>
              </Grid>
            ))}
        </Grid>
      </Grid>
    </Grid>
  );
};
export default memo(Imagecomponent);
