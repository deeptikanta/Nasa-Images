import { useDispatch, useSelector } from "react-redux";
import Imagecomponent from "../imagecomponent/imageComponent";
import { useParams } from "react-router-dom";
import { useEffect } from "react";
import fetchNasaImages from "../service/apiService";
import { isArrowFunction } from "typescript";

function SearchResult() {
  let { id } = useParams();
  let dispatch = useDispatch();
  const data = useSelector((state: any) => state.imageReducer.serchedData);
  const apiCalled = useSelector((state: any) => state.imageReducer.apiCalled);
  useEffect(() => {
    !apiCalled && getImages();
  }, [id]);
  const getImages = async () => {
    if (id) {
      dispatch({ type: "api-loading" });
      let data = await fetchNasaImages(id);
      Array.isArray(data)
        ? dispatch({ type: "search-Images", payload: data })
        : dispatch({ type: "loading-complete" });
    }
  };

  return (
    <div className="border">
      {apiCalled && data.length == 0 ? (
        <span className="discover-text">No Data Present</span>
      ) : (
        <Imagecomponent data={data} />
      )}
    </div>
  );
}
export default SearchResult;
