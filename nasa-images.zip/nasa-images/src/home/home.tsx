import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import fetchNasaImages from "../service/apiService";
import Imagecomponent from "../imagecomponent/imageComponent";

const Home = () => {
  const data = useSelector((state: any) => state.imageReducer.data);
  const dispatch = useDispatch();
  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = async () => {
    const data = await fetchNasaImages();
    dispatch({ type: "intial-Images", paylod: data });
  };
  return (
    <div className="border">
      <Imagecomponent data={data} />
    </div>
  );
};

export default Home;
