import { combineReducers } from "redux";

// Reducers
const initialState = {
  data: [],
  serchedData: [],
  loading: false,
  apiCalled: false,
};

const imageReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case "api-loading":
      return { ...state, loading: true, apiCalled: false };
    case "loading-complete":
      return { ...state, loading: false, apiCalled: true };
    case "intial-Images":
      return { ...state, data: action.paylod, loading: false };
    case "search-Images":
      return {
        ...state,
        serchedData: action.payload,
        loading: false,
        apiCalled: true,
      };

    default:
      return state;
  }
};

// Combine Reducers
const rootReducer = combineReducers({
  imageReducer,
  // Add other reducers here if you have more
});

export default rootReducer;
