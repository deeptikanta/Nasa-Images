import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useSelector } from "react-redux";
import { LinearProgress } from "@mui/material";
import React from "react";
import "./App.css";
import { Header } from "./header/header";
import Home from "./home/home";
import SearchResult from "./searchResult/searchResult";

function App() {
  const loading = useSelector((state: any) => state.imageReducer.loading);
  return (
    <React.Fragment>
      <Router>
        <Header />
        {loading ? (
          <LinearProgress color="inherit" />
        ) : (
          <Routes>
            <Route path="/" Component={Home} />
            <Route path="/search/:id" Component={SearchResult} />
          </Routes>
        )}
      </Router>
    </React.Fragment>
  );
}

export default App;
