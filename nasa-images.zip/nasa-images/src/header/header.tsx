import { Grid } from "@mui/material";
import "./header.css";
import SearchIcon from "@mui/icons-material/Search";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import fetchNasaImages from "../service/apiService";
import { useDispatch } from "react-redux";

export const Header = () => {
  const [value, setValue] = useState("");
  let navigate = useNavigate();
  let dispatch = useDispatch();
  const onHandleClick = async () => {
    if (value) {
      dispatch({ type: "api-loading" });
      let data = await fetchNasaImages(value);
      Array.isArray(data)
        ? dispatch({ type: "search-Images", payload: data })
        : dispatch({ type: "loading-complete" });
      setValue("");
      navigate(`/search/${value}`);
    }
  };
  return (
    <header>
      <div className="header-container">
        <Grid
          container
          justifyContent={"flex-end"}
          style={{ paddingTop: "35px" }}
        >
          <Grid item lg={5} xs={7}>
            <Grid container justifyContent={"center"} alignItems="center">
              <Grid item xs={2}>
                <span className="nasa-logo-alt">
                  NASA Image and <br />
                  Video Library
                </span>
              </Grid>
              <Grid item xs={2}>
                <Link to="/">
                  <img
                    src="https://images.nasa.gov/images/nasa_logo-large.png?as=webp"
                    className="logo"
                    alt="NASA"
                  />
                </Link>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid
          container
          direction="row"
          justifyContent="center"
          alignItems="flex-start"
        >
          <Grid item xs={6} style={{ padding: "60px" }}>
            <span className="discover">Discover</span>
            <span className="discover-text">
              our intergalactic multimedia collections
            </span>
            <br />
            <br />
            <div className="inputSearch">
              <input
                type="text"
                placeholder="Search for ...(e.g origin)"
                value={value}
                onChange={(e) => setValue(e.target.value)}
              />
              <button onClick={onHandleClick}>
                <SearchIcon
                  color="primary"
                  style={{ fontSize: "40px", color: "#fff" }}
                />
              </button>
            </div>
          </Grid>
        </Grid>
      </div>
    </header>
  );
};
